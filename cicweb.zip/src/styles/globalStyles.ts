import { createGlobalStyle } from 'styled-components'

export default createGlobalStyle`
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        scroll-behavior: smooth;
    }
    *, button, input {
        font-family: Roboto, sans-serif;
        -webkit-font-smoothing: antialiased;
    }

    :root {
        --color-primary: #0084d1;
        --color-secondary: #f9f9f9;
        --color-tertiary: #f9f9f9;
        --color-description: #6e6e6e;
        --color-quaternary: #000;
        --color-blue: #0061ff;
        --color-border: #bdc4c9;
    }
`