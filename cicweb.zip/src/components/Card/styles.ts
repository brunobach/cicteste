import styled from 'styled-components';

export const Container = styled.div`
  width: 20rem;
  height: 20rem;
  border: 3px solid;
  border-image-source: linear-gradient(45deg, rgb(0,143,104), rgb(250,224,66));
  border-image-slice: 1;


`;

export const Icon  = styled.div`
padding: 0.5rem;
width: 4rem;
height: 4rem;
background-color: white;
z-index: 10;

`;



export const Content = styled.div`
display: flex;
flex-direction: column;
justify-content: center;
align-items: center;
>h2 {
 margin-top: 3rem;
 color: var(--color-blue);
}

`;