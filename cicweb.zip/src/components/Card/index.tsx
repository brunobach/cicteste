import React from 'react';
import * as SvgIcons from 'react-icons/fa'
import {IconContext} from 'react-icons'
import { Container, Icon, Content} from './styles';

interface Props {
    IconVariant: "FaLayerGroup" | "FaCloud" | "FaDatabase" | "FaShieldAlt" | "FaSitemap" | "FaLandmark" | "FaExclamationTriangle" | "FaBalanceScale" | "FaProjectDiagram" | "FaBook" | "FaChartLine"
    title: string;
    description: string;
}



const Card: React.FC<Props> = ({IconVariant, title, description}) => {
 const IconSvg = SvgIcons[IconVariant]

  return <Container >
      <Icon>
      <svg>
        <defs>
          <linearGradient id="myGradient" gradientTransform="rotate(90)">
            <stop offset="5%"  stopColor="green" />
            <stop offset="95%" stopColor="#0061ff" />
          </linearGradient>
        </defs>
        <IconContext.Provider value={{ attr: {fill: "url('#myGradient')"}}}>
          <IconSvg size="2.8rem"  />
        </IconContext.Provider>
      </svg>
      </Icon>
      <Content>
          <h2>{title}</h2>
          <p> {description} </p>
      </Content>
  </Container>;
}

export default Card;