import React, { useEffect, useState } from "react";

import pc from "../../assets/pc.png";
import logo from "../../assets/cic-logo.png";
import EffectBlue from '../../assets/effectblue.svg'
import Outlined from '../../assets/outlined.svg'
import OutlinedBlue from '../../assets/outlined-blue.svg'
import document from '../../assets/document.png'
import halftone from '../../assets/hallftone.png'

import Card from '../Card'

import {
  Container,
  HeaderWrapper,
  Header,
  HeaderLink,
  Content,
  ContentBody,
  ButtonHamburger
} from "./styles";
import { setInterval } from "timers";

interface Props {
  variant: "inicio" | "video" | "funcionalidades" | "contato"  | "footer";
  title: string;
  description: string;
}

const Section: React.FC<Props> = ({ variant, title, description }) => {
  const [generateClasses, setGenerateClasses] = useState<number[]>([1,2,3,4,5]);
 
  useEffect(() => {
    setInterval(() => {
        const generatedNumbers = generateNumbers();
        setGenerateClasses(generatedNumbers)
    }, 4000);
 }, [])
  function generateNumbers(){
    return Array.from({length: 5}, () => Math.floor(Math.random() * 5 + 1 ));
  }

  return (
    <Container className={variant}>
      <HeaderWrapper>
        <Header>
          <h1>
            <img src={logo} alt="Logo Cic" />
          </h1>
          <HeaderLink></HeaderLink>
           <ButtonHamburger/>
        </Header>
      </HeaderWrapper>
      <img className="img-effect" src={EffectBlue} alt="Effect" />
      <img className="img-outlined" src={Outlined} alt="Effect" />
      <img className="img-outlined-blue" src={OutlinedBlue} alt="Effect" />
      <img className="img-halfftone" src={halftone} alt="Effect" />
      <Content>
        
        <ContentBody>
          <h2>{title}</h2>
          <p>{description}</p>
          <video width="800" controls>
                <source src='../../assets/Mov.MP4' type="video/mp4" />
          </video>
          <div className="card">
          <Card IconVariant="FaCloud" title="CARD EXAMPLE" description="Description Test" />
          </div>
        </ContentBody>
        <img src={pc} alt="Pc" />
        <img className={`document-${generateClasses[0]}`} src={document} alt="Document" />
        <img className={`document-${generateClasses[1]}`} src={document} alt="Document" />
        <img className={`document-${generateClasses[2]}`} src={document} alt="Document" />
        <img className={`document-${generateClasses[3]}`} src={document} alt="Document" />
        <img className={`document-${generateClasses[4]}`} src={document} alt="Document" />

        <svg>
          <path
            d="M38.4 15l1-3h1l1.2 3c.2.2.5.2.7.3l2.2-2.5 1 .4-.2 3.3c.2 0 .3.2.5.4l3-1.5.7.7-1.4 3 .5.5h3.3l.4.8-2.5 2.2c0 .2 0 .5.2.7l3 1v1l-3 1.2-.3.8 2.5 2-.4 1-3.3-.2-.4.7 1.5 2.8-.7.7-3-1.4c0 .2-.4.4-.6.5l.2 3.3-1 .4-2-2.5c-.3 0-.6 0-1 .2l-1 3h-1l-1-3c-.2-.2-.5-.2-.8-.3l-2 2.5-1-.4.2-3.3-.7-.4-2.8 1.5-.7-.7 1.4-3c-.2 0-.4-.4-.5-.6l-3.3.2-.4-1 2.5-2c0-.3 0-.6-.2-1l-3-1v-1l3-1c.2-.2.2-.4.3-.7l-2.5-2.2.4-1 3.3.2c0-.2.2-.3.4-.5l-1.5-3 .7-.7 3 1.4.5-.5v-3.3l.8-.4 2.2 2.5s.5 0 .7-.2z"
            fill="#5f0"
            transform="rotate(158.66455199999967 40 25)"
          >
            <animateTransform
              attributeType="xml"
              attributeName="transform"
              type="rotate"
              from="158.66455199999967 40 25"
              to="-150.66455199999967 40 25"
              dur="10s"
              additive="sum"
              repeatCount="indefinite"
            />
          </path>
          <circle fill="#ffff" cx="40" cy="25" r="2"></circle>
          <path
            d="M21.6 26.8L19 25l-1.3 1 1.4 3c0 .2-.3.4-.5.6l-3-.8-1 1.4 2.4 2.3-.4.8-3.2.3-.3 1.6 3 1.4v.8l-3 1.4.4 1.6 3.2.3c0 .3.2.5.3.8l-2.4 2.3.8 1.4 3-.8.7.6-1.3 3 1.3 1 2.6-1.8c.3 0 .5.3.8.4l-.3 3.2 1.6.6 2-2.7c.2 0 .5 0 .7.2l1 3h1.5l1-3c0-.2.4-.2.7-.3l2 2.7 1.4-.6-.4-3.2c.3 0 .5-.3.8-.4L37 49l1.3-1-1.4-3c0-.2.3-.4.5-.6l3 .8 1-1.4-2.4-2.3.4-.8 3.2-.3.3-1.6-3-1.4v-.8l3-1.4-.4-1.6-3.2-.3c0-.3-.2-.5-.3-.8l2.4-2.3-.8-1.4-3 .8-.7-.6 1.3-3-1.3-1-2.6 1.8c-.3 0-.5-.3-.8-.4l.3-3.2-1.6-.6-2 2.7c-.2 0-.5 0-.7-.2l-1-3h-1.5l-1 3c0 .2-.4.2-.7.3l-2-2.7-1.4.6.4 3.2c-.3 0-.5.3-.8.4z"
            fill="#ccccc7"
            transform="rotate(-158.66455199999967 28 37)"
          >
            <animateTransform
              attributeType="xml"
              attributeName="transform"
              type="rotate"
              from="-158.66455199999967 28 37"
              to="158.66455199999967 28 37"
              dur="10s"
              additive="sum"
              repeatCount="indefinite"
            />
          </path>
          <circle fill="#ffff" cx="28" cy="37" r="3"></circle>
        </svg>
      </Content>
    </Container>
  );
};

export default Section;
