import styled from "styled-components";
import {HiMenu} from 'react-icons/hi'


export const Container = styled.div`
  --padding-top: 100px;
  --padding-bottom: 120px;
  --heading-font-size: 32px;
  --content-width: 100%;
  --video-display: none;
  --direction-flex: row;
  &.video {
    --card-display: none;
    --bg-color: var(--color-primary);
    --text-color: var(--color-tertiary);
    --logo-color: var(--color-secondary);
    background: linear-gradient(
    -2deg,
    var(--color-tertiary) calc(10% - 1px),
    var(--color-primary) 10%
  );
  --video-display: hidden;
  }
  &.funcionalidades {
    --bg-color: var(--color-secondary);
    --next-color: var(----color-border);
    --text-color: var(--color-quaternary);
    --logo-color: var(--color-primary);
    --content-width: 75%;
    --margin-left: 25%;
    --card-display: hidden;
    --direction-flex: column;
  }
  &.inicio {
    --bg-color: var(--color-tertiary);
    --next-color: var(--color-primary);
    --text-color: var(--color-description);
    --logo-color: var(--color-primary);
  }
  &.contato {
    --card-display: none;
    --bg-color: var(--color-quaternary);
    --text-color: var(--color-tertiary);
    --logo-color: var(--color-blue);
  }

  &:first-child {
    --padding-top: 130px;
    --heading-font-size: 51px;
    --image-display: hidden;

    @media (min-width: 1024px) {
      --content-width: 75%;
      --heading-font-size: 40px;
    }
  }
  &:nth-child(2) {
    --text-align: row;
    --margin-left: 9%;
    --content-width: 300px;
  }
  --text-align: column;
  --image-display: none;
  background: linear-gradient(
    3deg,
    var(--next-color) calc(15% - 1px),
    var(--bg-color) 15%
  );
  position: relative;
  .img-effect {
        display: var(--image-display);
        position: absolute;
        left: -2%;
        top: 40%;
        width: 20rem;
    }
    .img-outlined {
        display: var(--image-display);
        position: absolute;
        left: -4%;
        top: 10%;
        width: 25rem;
    }
    .img-outlined-blue {
        display: var(--image-display);

        position: absolute;
        right: 0%;
        top: 49%;
        width: 25rem;
    }
    .img-halfftone {
        display: var(--image-display);

        position: absolute;
        right: 20%;
        top: 30%;
        width: 10rem;
        opacity: 0.4;
    }

    
`;

export const HeaderWrapper = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;

  clip: rect(auto, auto, auto, auto);
`;

export const HeaderLink = styled.div`
  display: flex;
  flex-grow: 1;
  pointer-events: all;

  > a {
    color: var(--text-color);
    outline: none;
    text-decoration: none;
    margin-top: 5px;
    padding: 20px 15px;
    font-size: 16px;
    appearance: none;
    font-weight: 300;
    -webkit-font-smoothing: antialiased;

    &:hover {
      text-decoration: underline;
    }
  }
`;

export const Header = styled.header`
  z-index: 3;
  background: var(--bg-color);

  display: flex;
  justify-content: space-between;
  align-items: center;

  padding: 20px 0 0 10%;
  padding-bottom: 10px;

  > h1 {
    display: flex;
    align-items: center;

    > img {
      width: 200px;
    }
    > span {
      color: var(--text-color);
      margin: 10px 16px;
      width: 35%;
      word-wrap: break-word;
      font-weight: 700;
      font-size: 15px;
    }
  }
  > button {
    color: var(--text-color);
    background: none;
    border: none;
    outline: none;
    font-size: 16px;
    cursor: pointer;

    &:hover,
    &:focus {
      text-decoration: underline;
    }
  }

  position: fixed;
  top: 0;
  left: 0;
  right: 0;
`;
export const ButtonHamburger = styled(HiMenu)`
   width: 60px;
   height: 60px;
    margin-right: 20%;
    fill: #0084d1;
`
export const Content = styled.div`
  z-index: 2;
  position: relative;
  max-width: 1440px;
  margin: 0 auto;

  display: flex;
  flex-direction: var(--direction-flex);
  

  > button {
    display: var(--image-display);
    background-color: transparent;
    position: absolute;
    z-index: 1;
    margin-top: -220px;
    width: 40px;
    height: 60px;
    border: 0;
    margin: -220px 0 20 0;
    overflow: hidden;
    cursor: pointer;
    > svg {
      position: relative;
      animation-name: arrow;
      animation-duration: 1.5s;
      animation-iteration-count: infinite;
    }

    @keyframes arrow {
      0% {
        top: 0px;
      }
      25% {
        top: 10px;
      }
      50% {
        top: 20px;
      }
      75% {
        top: 40px;
      }
      100% {
        top: 50px;
      }
    }
  }
  > img {
    width: 700px;
    display: var(--image-display);
  }

  > .document-1 {
    position: absolute;
    width: 32px;
    left: 73%;
    top: 40%;
    margin: -12px 0 0 -12px;
    animation: rol1 5s ease-out infinite both;
  }
  > .document-2 {
    position: absolute;
    width: 32px;
    left: 68%;
    top: 40%;
    margin: -12px 0 0 -12px;
    animation: rol2 5s ease-out infinite both;
  }
  > .document-3 {
    position: absolute;
    width: 32px;
    left: 70%;
    top: 40%;
    margin: -12px 0 0 -12px;
    animation: rol3 5s ease-out infinite both;
  }
  > .document-4 {
    position: absolute;
    width: 32px;
    left: 71%;
    top: 45%;
    margin: -12px 0 0 -12px;
    animation: rol4 5s ease-out infinite both;
  }
  > .document-5 {
    position: absolute;
    width: 32px;
    left: 72%;
    top: 42%;
    margin: -12px 0 0 -12px;
    animation: rol5 5s ease-out infinite both;
  }

  @keyframes rol1 {
    0% {
      transform: translateX(-80px) translateY(-30px) rotate(20deg);
      opacity: 0.7;
    }
    100% {
      transform: translateX(0) rotate(0deg);
      opacity: 0;
    }
  }
  @keyframes rol2 {
    0% {
      transform: translateX(-45px) translateY(-10px) rotate(218deg);
      opacity: 0.6;
    }
    100% {
      transform: translateX(0) rotate(0deg);
      opacity: 0;
    }
  }
  @keyframes rol3 {
    0% {
      transform: translateX(-100px) translateY(-50px) rotate(120deg);
      opacity: 0.6;
    }
    100% {
      transform: translateX(0) rotate(0deg);
      opacity: 0;
    }
  }
  @keyframes rol4 {
    0% {
      transform: translateX(-85px) translateY(100px) rotate(108deg);
      opacity: 0.4;
    }
    100% {
      transform: translateX(0) rotate(0deg);
      opacity: 0;
    }
  }
  @keyframes rol5 {
    0% {
      transform: translateX(-150px) translateY(-80px) rotate(20deg);
      opacity: 0.7;
    }
    100% {
      transform: translateX(0) rotate(0deg);
      opacity: 0;
    }
  }

  > svg {
    display: var(--image-display);
    position: absolute;
    left: 72%;
    top: 38%;
    transform: perspective(200px) rotateX(-20deg);
    transform-style: preserve-3d;
  }

  padding: var(--padding-top) 32px var(--padding-bottom);
`;

export const ContentBody = styled.div`
  display: flex;
  flex-direction: column;
  max-width: var(--content-width);
  > h2 {
    font-size: var(--heading-font-size);
    color: var(--logo-color);
    line-height: 45px;
    letter-spacing: -3px;   
    margin-left: var(--margin-left);
  }
  > p {
    margin-top: 20px;
    font-size: 17px;
    font-weight: 400;
    line-height: 30px;
    letter-spacing: -0.3px;
    text-align: justify;
    font-family: 'Noto Sans', sans-serif;
    text-justify: inter-word;
    color: var(--text-color);
    max-width: var(--content-width);
    margin-left: var(--margin-left);
  }
  > video {
    display: flex;
    justify-content: center;
    display: var(--video-display);
  }
  .card {
    display: var(--card-display);
  }
`;
