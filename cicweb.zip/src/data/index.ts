export default [
  {
    title:
      "QUE TAL CONTROLAR SUAS COMPENSAÇÕES TRIBUTÁRIAS FEDERAIS DE UM JEITO SIMPLES E SEGURO?",
    description:
      "Agora, você pode contar como CIC, uma plataforma digital, exclusiva e dedicada ao controle de compensações de tributos federais e que pode ser personalizada na medida exata das necessidades da sua empresa. Com ele, você monitora sua cadeia de compensações de ponta a ponta, isto é, desde a geração de PER/DCOMPs de crédito e débito, passando por trâmites administrativos, até a decisão final de processos administrativos. Tudo isso de forma inteligente, integrada, intuitiva e totalmente alinhada com a legislação tributária brasileira.",
  },
  {
    title: "CONHEÇA NOSSAS PRINCIPAIS FUNCIONALIDADES E VEJA COMO PODEMOS FACILITAR A SUA ROTINA",
    description:
      "",
  },
  {
    title: "",
    description:
      "",
  },
  {
    title: "",
    description: "",
  },
  {
    title: "",
    description:
      "",
  },
];
